-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fm91_radio_managment_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `fm91_shows_data`
--

CREATE TABLE `fm91_shows_data` (
  `id` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Show_1_Name` varchar(40) NOT NULL,
  `Show_1_Author_Name` varchar(40) NOT NULL,
  `Show_1_Image` varchar(250) NOT NULL,
  `Show_1_Detail` varchar(250) NOT NULL,
  `Show_1_Download_Link` varchar(250) NOT NULL,
  `Show_1_Start_Time` time NOT NULL,
  `Show_1_Close_Time` time NOT NULL,
  `Show_2_Name` varchar(40) NOT NULL,
  `Show_2_Author_Name` varchar(40) NOT NULL,
  `Show_2_Image` varchar(250) NOT NULL,
  `Show_2_Detail` varchar(250) NOT NULL,
  `Show_2_Download_Link` varchar(100) NOT NULL,
  `Show_2_Start_Time` time NOT NULL,
  `Show_2_Close_Time` time NOT NULL,
  `Show_3_Name` varchar(40) NOT NULL,
  `Show_3_Author_Name` varchar(40) NOT NULL,
  `Show_3_Image` varchar(100) NOT NULL,
  `Show_3_Detail` varchar(250) NOT NULL,
  `Show_3_Download_Link` varchar(100) NOT NULL,
  `Show_3_Start_Time` time NOT NULL,
  `Show_3_Close_Time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` char(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'maaz', '$2a$12$yfZWALPbXlH2iWKUhpzlgONm91EbbmUHdSx9bBJqh2NZ4vjLXgYRu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



-- Daily Schedule Query

CREATE TABLE `fm91_rms`.`day#1` ( `Id` INT(5) NOT NULL AUTO_INCREMENT ,
 `ShowName` VARCHAR(45) NOT NULL ,
 `AuthorName` VARCHAR(45) NOT NULL ,
 `Details` VARCHAR(250) NOT NULL ,
 `ShowPicture` VARCHAR(100) NOT NULL ,
 `DownloadLink` VARCHAR(100) NOT NULL ,
 `Start-Time` TIME NOT NULL ,
 `Close-Time` TIME NOT NULL ,
  PRIMARY KEY (`Id`)) ENGINE = InnoDB;

  