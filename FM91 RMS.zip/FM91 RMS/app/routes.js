const mysql = require('mysql');
const dbconfig = require('../config/database');
var connection = mysql.createConnection(dbconfig.connection);
// app/routes.js
module.exports = function (app, passport) {


	// HOME PAGE

	app.get('/', function (req, res) {
		res.render('index.ejs');
	});

	// LOGIN ===============================
	
	app.get('/login', function (req, res) {

		// render the page and pass in any flash data if it exists
		res.render('login.ejs', { message: req.flash('loginMessage') });
	});

	// process the login form
	app.post('/login', passport.authenticate('local-login', {
		successRedirect: '/profile', // redirect to the secure profile section
		failureRedirect: '/login', // redirect back to the signup page if there is an error
		failureFlash: true // allow flash messages
	}),
		function (req, res) {
			console.log("hello");

			if (req.body.remember) {
				req.session.cookie.maxAge = 1000 * 60 * 3;
			} else {
				req.session.cookie.expires = false;
			}
			res.redirect('/');
		});

	// =====================================
	// PROFILE SECTION =========================
	// =====================================
	// we will want this protected so you have to be logged in to visit
	// we will use route middleware to verify this (the isLoggedIn function)
	app.get('/profile', isLoggedIn, function (req, res) {
		res.render('profile.ejs', {
			user: req.user // get the user out of session and pass to template
		});
	});

	// =================================
	// Schedule Section
	app.get('/profile/schedule', isLoggedIn, function (req, res) {
		connection.query('SELECT * FROM fm91_shows_data', (err, rows) => {
			connection.release
			if (!err) {
				res.render('schedule.ejs', { data: rows })
			} else {
				console.log(err);
			}
			console.log('The data from fm91_shows_data table; \n', rows);
		})
	})
	// =====================================
	// View Section
	app.get('/profile/schedule/viewschedule/:id', isLoggedIn, function (req, res) {
		connection.query('SELECT * FROM fm91_shows_data WHERE id = ?', [req.params.id], (err, rows) => {
			connection.release
			if (!err) {
				res.render('viewschedule.ejs', { viewdata: rows })
			} else {
				console.log(err);
			}
			console.log('The data from fm91_shows_data table; \n', rows);
		})
	})

	// =========================================
	// Edit Section
	app.get('/profile/schedule/editschedule/:id', isLoggedIn, function (req, res) {
		connection.query('SELECT * FROM fm91_shows_data WHERE id = ?', [req.params.id], (err, rows) => {
			connection.release
			if (!err) {
				res.render('editschedule.ejs')
			}
		})
	})

	
	// =========================================
	// Add Section
	app.get('/profile/schedule/addschedule', isLoggedIn, function (req, res) {
		res.render('addschedule.ejs')
	})



	app.post('/profile/schedule/addschedule', function (req, res) {
		    req.body.id,
			req.body.Date,
			req.body.Show_1_Name,
			req.body.Show_1_Author_Name,
			req.files.Show_1_Image,
			req.body.Show_1_Detail,
			req.body.Show_1_Download_Link,
			req.body.Show_1_Start_Time,
			req.body.Show_1_Close_Time,
			req.body.Show_2_Name,
			req.body.Show_2_Author_Name,
			req.files.Show_2_Image,
			req.body.Show_2_Detail,
			req.body.Show_2_Download_Link,
			req.body.Show_2_Start_Time,
			req.body.Show_2_Close_Time,
			req.body.Show_3_Name,
			req.body.Show_3_Author_Name,
			req.files.Show_3_Image,
			req.body.Show_3_Detail,
			req.body.Show_3_Download_Link,
			req.body.Show_3_Start_Time,
			req.body.Show_3_Close_Time,
			req.body.Show_4_Name,
			req.body.Show_4_Author_Name,
			req.files.Show_4_Image,
			req.body.Show_4_Detail,
			req.body.Show_4_Download_Link,
			req.body.Show_4_Start_Time,
			req.body.Show_4_Close_Time,
			req.body.Show_5_Name,
			req.body.Show_5_Author_Name,
			req.files.Show_5_Image,
			req.body.Show_5_Detail,
			req.body.Show_5_Download_Link,
			req.body.Show_5_Start_Time,
			req.body.Show_5_Close_Time,
			req.body.Show_6_Name,
			req.body.Show_6_Author_Name,
			req.files.Show_6_Image,
			req.body.Show_6_Detail,
			req.body.Show_6_Download_Link,
			req.body.Show_6_Start_Time,
			req.body.Show_6_Close_Time,
			req.body.Show_7_Name,
			req.body.Show_7_Author_Name,
			req.files.Show_7_Image,
			req.body.Show_7_Detail,
			req.body.Show_7_Download_Link,
			req.body.Show_7_Start_Time,
			req.body.Show_7_Close_Time,
			req.body.Show_8_Name,
			req.body.Show_8_Author_Name,
			req.files.Show_8_Image,
			req.body.Show_8_Detail,
			req.body.Show_8_Download_Link,
			req.body.Show_8_Start_Time,
			req.body.Show_8_Close_Time,
			req.body.Show_9_Name,
			req.body.Show_9_Author_Name,
			req.files.Show_9_Image,
			req.body.Show_9_Detail,
			req.body.Show_9_Download_Link,
			req.body.Show_9_Start_Time,
			req.body.Show_9_Close_Time,
			req.body.Show_10_Name,
			req.body.Show_10_Author_Name,
			req.files.Show_10_Image,
			req.body.Show_10_Detail,
			req.body.Show_10_Download_Link,
			req.body.Show_10_Start_Time,
			req.body.Show_10_Close_Time,
			req.body.Show_11_Name,
			req.body.Show_11_Author_Name,
			req.files.Show_11_Image,
			req.body.Show_11_Detail,
			req.body.Show_11_Download_Link,
			req.body.Show_11_Start_Time,
			req.body.Show_11_Close_Time,
			req.body.Show_12_Name,
			req.body.Show_12_Author_Name,
			req.files.Show_12_Image,
			req.body.Show_12_Detail,
			req.body.Show_12_Download_Link,
			req.body.Show_12_Start_Time,
			req.body.Show_12_Close_Time;
		    let file1 = req.files.Show_1_Image;
		    let file2 = req.files.Show_2_Image;
		    let file3 = req.files.Show_3_Image;
		    let file4 = req.files.Show_4_Image;
		    let file5 = req.files.Show_5_Image;
		    let file6 = req.files.Show_6_Image;
		    let file7 = req.files.Show_7_Image;
		    let file8 = req.files.Show_8_Image;
		    let file9 = req.files.Show_9_Image;
		    let file10 = req.files.Show_10_Image;
		    let file11 = req.files.Show_11_Image;
		    let file12 = req.files.Show_12_Image;
		    var show1_pic = file1.name;
		    var show2_pic = file2.name;
		    var show3_pic = file3.name;
		    var show4_pic = file4.name;
		    var show5_pic = file5.name;
		    var show6_pic = file6.name;
		    var show7_pic = file7.name;
		    var show8_pic = file8.name;
		    var show9_pic = file9.name;
		    var show10_pic = file10.name;
		    var show11_pic = file11.name;
		    var show12_pic = file12.name;
		    // let file2 = NIC_Front;
		    // var nic_front=file2.name;
		    // let file3 = NIC_Back;
		    // var nic_back=file3.name;
		    file1.mv('./public/upload_images/' + show1_pic);
		    file2.mv('./public/upload_images/' + show2_pic);
		    file3.mv('./public/upload_images/' + show3_pic);
		    file4.mv('./public/upload_images/' + show4_pic);
		    file5.mv('./public/upload_images/' + show5_pic);
		    file6.mv('./public/upload_images/' + show6_pic);
		    file7.mv('./public/upload_images/' + show7_pic);
		    file8.mv('./public/upload_images/' + show8_pic);
		    file9.mv('./public/upload_images/' + show9_pic);
		    file10.mv('./public/upload_images/' + show10_pic);
		    file11.mv('./public/upload_images/' + show11_pic);
		    file12.mv('./public/upload_images/' + show12_pic);
		    connection.query('INSERT INTO fm91_shows_data SET Date = ?, Show_1_Name = ?, Show_1_Author_Name = ?, Show_1_Image = ?, Show_1_Detail = ?, Show_1_Download_Link = ?, Show_1_Start_Time = ?, Show_1_Close_Time = ?, Show_2_Name = ?, Show_2_Author_Name = ?, Show_2_Image = ?, Show_2_Detail = ?, Show_2_Download_Link = ?, Show_2_Start_Time = ?, Show_2_Close_Time = ?, Show_3_Name = ?, Show_3_Author_Name = ?, Show_3_Image = ?, Show_3_Detail = ?, Show_3_Download_Link = ?, Show_3_Start_Time = ?, Show_3_Close_Time = ?, Show_4_Name = ?, Show_4_Author_Name = ?, Show_4_Image = ?, Show_4_Detail = ?, Show_4_Download_Link = ?, Show_4_Start_Time = ?, Show_4_Close_Time = ?, Show_5_Name = ?, Show_5_Author_Name = ?, Show_5_Image = ?, Show_5_Detail = ?, Show_5_Download_Link = ?, Show_5_Start_Time = ?, Show_5_Close_Time = ?, Show_6_Name = ?, Show_6_Author_Name = ?, Show_6_Image = ?, Show_6_Detail = ?, Show_6_Download_Link = ?, Show_6_Start_Time = ?, Show_6_Close_Time = ?, Show_7_Name = ?, Show_7_Author_Name = ?, Show_7_Image = ?, Show_7_Detail = ?, Show_7_Download_Link = ?, Show_7_Start_Time = ?, Show_7_Close_Time = ?, Show_8_Name = ?, Show_8_Author_Name = ?, Show_8_Image = ?, Show_8_Detail = ?, Show_8_Download_Link = ?, Show_8_Start_Time = ?, Show_8_Close_Time = ?, Show_9_Name = ?, Show_9_Author_Name = ?, Show_9_Image = ?, Show_9_Detail = ?, Show_9_Download_Link = ?, Show_9_Start_Time = ?, Show_9_Close_Time = ?, Show_10_Name = ?, Show_10_Author_Name = ?, Show_10_Image = ?, Show_10_Detail = ?, Show_10_Download_Link = ?, Show_10_Start_Time = ?, Show_10_Close_Time = ?, Show_11_Name = ?, Show_11_Author_Name = ?, Show_11_Image = ?, Show_11_Detail = ?, Show_11_Download_Link = ?, Show_11_Start_Time = ?, Show_11_Close_Time = ?, Show_12_Name = ?, Show_12_Author_Name = ?, Show_12_Image = ?, Show_12_Detail = ?, Show_12_Download_Link = ?, Show_12_Start_Time = ?, Show_12_Close_Time = ?', [
			req.body.Date,
			req.body.Show_1_Name,
			req.body.Show_1_Author_Name,
			show1_pic,
			req.body.Show_1_Detail,
			req.body.Show_1_Download_Link,
			req.body.Show_1_Start_Time,
			req.body.Show_1_Close_Time,
			req.body.Show_2_Name,
			req.body.Show_2_Author_Name,
			show2_pic,
			req.body.Show_2_Detail,
			req.body.Show_2_Download_Link,
			req.body.Show_2_Start_Time,
			req.body.Show_2_Close_Time,
			req.body.Show_3_Name,
			req.body.Show_3_Author_Name,
			show3_pic,
			req.body.Show_3_Detail,
			req.body.Show_3_Download_Link,
			req.body.Show_3_Start_Time,
			req.body.Show_3_Close_Time,
			req.body.Show_4_Name,
			req.body.Show_4_Author_Name,
			show4_pic,
			req.body.Show_4_Detail,
			req.body.Show_4_Download_Link,
			req.body.Show_4_Start_Time,
			req.body.Show_4_Close_Time,
			req.body.Show_5_Name,
			req.body.Show_5_Author_Name,
			show5_pic,
			req.body.Show_5_Detail,
			req.body.Show_5_Download_Link,
			req.body.Show_5_Start_Time,
			req.body.Show_5_Close_Time,
			req.body.Show_6_Name,
			req.body.Show_6_Author_Name,
			show6_pic,
			req.body.Show_6_Detail,
			req.body.Show_6_Download_Link,
			req.body.Show_6_Start_Time,
			req.body.Show_6_Close_Time,
			req.body.Show_7_Name,
			req.body.Show_7_Author_Name,
			show7_pic,
			req.body.Show_7_Detail,
			req.body.Show_7_Download_Link,
			req.body.Show_7_Start_Time,
			req.body.Show_7_Close_Time,
			req.body.Show_8_Name,
			req.body.Show_8_Author_Name,
			show8_pic,
			req.body.Show_8_Detail,
			req.body.Show_8_Download_Link,
			req.body.Show_8_Start_Time,
			req.body.Show_8_Close_Time,
			req.body.Show_9_Name,
			req.body.Show_9_Author_Name,
			show9_pic,
			req.body.Show_9_Detail,
			req.body.Show_9_Download_Link,
			req.body.Show_9_Start_Time,
			req.body.Show_9_Close_Time,
			req.body.Show_10_Name,
			req.body.Show_10_Author_Name,
			show10_pic,
			req.body.Show_10_Detail,
			req.body.Show_10_Download_Link,
			req.body.Show_10_Start_Time,
			req.body.Show_10_Close_Time,
			req.body.Show_11_Name,
			req.body.Show_11_Author_Name,
			show11_pic,
			req.body.Show_11_Detail,
			req.body.Show_11_Download_Link,
			req.body.Show_11_Start_Time,
			req.body.Show_11_Close_Time,
			req.body.Show_12_Name,
			req.body.Show_12_Author_Name,
			show12_pic,
			req.body.Show_12_Detail,
			req.body.Show_12_Download_Link,
			req.body.Show_12_Start_Time,
			req.body.Show_12_Close_Time], (err, rows) => {
				connection.release
				if (!err) {
					res.render('addschedule.ejs', { alert: 'Shows Registered Succesfully' })
				} else {
					console.log(err);
				}
				console.log('The Date from schedulel; \n',);
			})
	})
	app.post('/profile/addplaylist', function (req, res) {
		req.body.Playlist_Nmae,
			req.files.music,
			req.files.picture,
			req.body.Details;
		let music = req.files.music;
		let picture = req.files.picture;
		var musics = music.name;
		var pictures = picture.name;
		music.mv('./public/upload_playlists/' + musics);
		picture.mv('./public/upload_playlists/' + pictures);
		connection.query('INSERT INTO playlist SET Playlist_Name = ?, music = ?, picture = ?, Details = ?', [
			req.body.Playlist_Name,
			musics,
			pictures,
			req.body.Details
		], (err, rows) => {
			connection.release
			if (!err) {
				res.render('playlists.ejs', { alert: 'Playlist Added Succesfully' })
			} else {
				console.log(err);
			}
		})

	});

	app.get('/profile/seeplaylists', isLoggedIn, function (req, res) {
		res.render('allplaylists.ejs');
	})
	// ==========================================
	// Api Section
	// Schedule Api
	app.get('/profile/scheduleApi', async function (req, res) {
		await connection.query('SELECT * FROM fm91_shows_data', (err, api) => {
			// when done with the connection release it
			connection.release
			if (!err) {

				res.write(JSON.stringify({ api }));
				res.end();
			} else {
				console.log(err)
			}
			console.log('The Data From User Table; \n ')
		})
	});

	app.get('/profile/playlist', isLoggedIn, function (req, res) {
		res.render('playlists.ejs');
	});
	// =====================================
	// LOGOUT ==============================
	// =====================================
	app.get('/logout', function (req, res) {
		req.logout();
		res.redirect('/');
	});
};
// route middleware to make sure
function isLoggedIn(req, res, next) {

	// if user is authenticated in the session, carry on
	if (req.isAuthenticated())
		return next();
	// if they aren't redirect them to the home page
	res.redirect('/');
}


