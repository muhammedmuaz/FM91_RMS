// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'fm91_rms',
    },
    'database': 'fm91_rms',
};